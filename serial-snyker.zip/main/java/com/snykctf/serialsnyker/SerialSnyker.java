package com.snykctf.serialsnyker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SerialSnyker {

	public static void main(String[] args) {
		SpringApplication.run(SerialSnyker.class, args);
	}

}
